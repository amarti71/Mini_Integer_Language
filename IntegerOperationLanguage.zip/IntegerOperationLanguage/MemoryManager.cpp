#include "MemoryManager.hpp"

MemoryManager::MemoryManager() {
	variables.clear();
}

bool MemoryManager::isInMemory(std::string name) {
	return variables.contains(name);
}

// this function will never be called before checking isInMemory()
int MemoryManager::getValue(std::string name) {
	return variables[name];
}

bool MemoryManager::editMemory(std::string name, int value) {
	if (isInMemory(name)) {
		variables[name] = value;
		return true;
	}
	return false;
}

bool MemoryManager::addToMemory(std::string name) {
	if (!isInMemory(name)) {
		variables.insert({name, 0});
		return true;
	} 
	return false;
}

bool MemoryManager::addToMemory(std::string name, int value) {
	if (!isInMemory(name)) {
		variables.insert({ name, value });
		return true;
	}
	return false;
}

