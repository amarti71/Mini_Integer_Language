#include <iostream>
#include "Evaluator.hpp"


int main() {

    bool programRunning = true;
    std::string input;

    Evaluator eval;

    // prompt the user
    std::cout << "Welcome to my integer math language!" << std::endl;
    std::cout << "type (END) anytime to exit the program safely" << std::endl << std::endl;

    // loop while user has not prompted to end
    while (programRunning) {
        // get the line and feed it to evalutaor if it is not "END"
        if (std::getline(std::cin, input) && !input.empty()) {
            if (input == "END") {
                programRunning = false;
            }
            else {
                eval.giveSegment(input);
                eval.processSegment();
            }
        }
    }


    return 0;
}