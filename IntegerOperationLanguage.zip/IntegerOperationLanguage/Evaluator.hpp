#ifndef EVALUATOR_SPECIFICATION_HPP
#define EVALUATOR_SPECIFICATION_HPP

#include "Parser.hpp"
#include "Tokenizer.hpp"
#include "MemoryManager.hpp"

class Evaluator {
	private:
		Parser parser;
		Tokenizer tokenizer;
		MemoryManager memory;
		std::string segment;
		void outputToConsole(int value, bool passed);
		int evaluateExpression(std::vector<Token> tokens);
		int preformOperation(int num1, int num2, Type type);

		bool refernceNotFound = false;

	public:
		Evaluator();
		void giveSegment(std::string segment);
		void processSegment();
};

#endif
