#include "evaluator.hpp"
#include <iostream>

Evaluator::Evaluator() {
	this->segment = "";
}

// output to consle based upon if there is not sytax issues
void Evaluator::outputToConsole(int value, bool passed) {
	if (passed) {
		std::cout << "> " << value << std::endl;
	}
	else {
		std::cout << "> SYNTAX ERROR!" << std::endl;
	}
}

void Evaluator::giveSegment(std::string value) {
	this->segment = value;
}

void Evaluator::processSegment() {

	//reset the global error state
	refernceNotFound = false;

	// hold the tokenized string in a vector
	std::vector<Token> tokens = tokenizer.tokenize(segment);
	// recycle the tokenizer for later use
	tokenizer.reuse();
	// give the parser the tokens
	parser.giveTokens(tokens);
	// hold the result of the token verification
	bool passed = parser.verify();

	// if the parser found an issue report back to console and dont proceed
	if (!passed) {
		outputToConsole(0, passed);
	}
	else { // if no issue was fiund
		// assigning to a variable
		if (tokens.size() >= 2 && tokens[1].tokenType == Assign) {
			int total = evaluateExpression(tokens);
			if (!refernceNotFound) {
				// verify that it has not already been alocated
				bool isNew = !memory.isInMemory(tokens[0].value);
				if (isNew) {
					memory.addToMemory(tokens[0].value, total);
				}
				else {
					memory.editMemory(tokens[0].value, total);
				}
			}
		}
		// creating a varible without initalization
		if (tokens.size() == 1 && tokens[0].tokenType == Reference) {
			// verifiy that it hasnt already been allocated
			bool isNew = !memory.isInMemory(tokens[0].value);
			if (isNew) {
				memory.addToMemory(tokens[0].value);
			}
		}
		// printing to console
		if (tokens[0].tokenType == Print && tokens.size() >= 2) {
			int total = evaluateExpression(tokens);
			if (!refernceNotFound) {
				outputToConsole(total, true);
			}
		}
	}

	// if an expressoin pointed to an undefined variable report back to the console and reset state
	if (refernceNotFound) {
		outputToConsole(0, !refernceNotFound);
	}
	refernceNotFound = false;

}

// evaluate what is to the right of the equal sign
int Evaluator::evaluateExpression(std::vector<Token> tokens) {
	// store the states for the algorithom
	Type NextOperation = Add;
	int lastNumber;
	int total = 0;
	int startIndex = 2;

	// if we are dealing with a print statment, start evaluating at the second index instead
	if (tokens[0].tokenType == Print) {
		startIndex = 1;
	}

	// loop up the evaluation
	for (int i = startIndex; i < tokens.size(); i+=2) {
		// current number being read
		int current;

		// if it is a refernece
		if (tokens[i].tokenType == Reference) {
			// check to see if that refernce is valid
			bool defined = memory.isInMemory(tokens[i].value);
			if (!defined) {
				// if it is not update the global state of error and exit loop
				refernceNotFound = true;
				break;
			}
			// if it is all good, set the current to the vlaue in memory
			current = memory.getValue(tokens[i].value);
		}
		else {
			// convert the string number to an int and store it in current
			current = std::stoi(tokens[i].value);
		}

		// if it is not the first number
		if (i != startIndex) {
			// make the total the opperated version using the current number
			total = preformOperation(total, current, NextOperation);
		}
		else {
			// if it is the start of the loop
			// set the total to be the first numebr
			total = current;
		}

		// if it is not the last item
		if (i != tokens.size() - 1) {
			// set the last number state and find the next operation to be done
			lastNumber = current;
			NextOperation = tokens[i + 1].tokenType;
		}

	}

	// return the total
	return total;

}

// take two numbers and preform an Operation on them based on the Operation type
int Evaluator::preformOperation(int num1, int num2, Type type) {
	if (type == Add) {
		return num1 + num2;
	}
	else if (type == Subtract) {
		return num1 - num2;
	}
	else if (type == Multiply) {
		return num1 * num2;
	}
	else {
		return (int)(num1 / num2);
	}
}