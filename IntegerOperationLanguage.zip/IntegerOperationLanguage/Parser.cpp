#include "Parser.hpp"

Parser::Parser() {
	this->tokens.clear();
}

void Parser::reuse() {
	this->tokens.clear();
}

// clear the tokens then set the tokens to the argument provided
void Parser::giveTokens(std::vector<Token> tokens) {
	this->reuse();
	this->tokens = tokens;
}

// verify the tokens acording to the syntax of the language
bool Parser::verify() {
	bool passingTest = true;

	for (int i = 0; i < this->tokens.size() && passingTest; i++) {
		Type thisType = this->tokens[i].tokenType;
		// test some cases that will always result in invalid syntax
		if (thisType == Print && i != 0) passingTest = false;
		if (thisType == Assign && i != 1) passingTest = false;

		// verify that Operations have a number or reference on each side
		if (thisType == Add || thisType == Subtract || thisType == Multiply || thisType == Divide) {
			// if it is in the first or last position, it is not a valid Operation
			if (i == 0 || i == this->tokens.size() - 1) passingTest = false;
			// make sure there is a refrence or integer on both the left and right side of the opperator
			else if (this->tokens[i - 1].tokenType != Reference && this->tokens[i - 1].tokenType != Integer) passingTest = false;
			else if (this->tokens[i + 1].tokenType != Reference && this->tokens[i + 1].tokenType != Integer) passingTest = false;
		}

		// verifiy that assignment has correct values on the right and left
		if (thisType == Assign) {
			// if it is in the first or last position, it is not a valid Operation
			// do this just to ensure that bounds will apply, does not get rid of the fact must be in second index
			if (i == 0 || i == this->tokens.size() - 1) passingTest = false;
			else if (this->tokens[i - 1].tokenType != Reference) passingTest = false;
			else if (this->tokens[i + 1].tokenType != Reference && this->tokens[i + 1].tokenType != Integer) passingTest = false;
		}

		// test the adjacecy of referneces and intengers

		if (thisType == Reference || thisType == Integer) {
			// if it is not the last token
			if (i != this->tokens.size() - 1) {
				// check infront to make sure there is no integer adjacency
				if (this->tokens[i + 1].tokenType == Reference || this->tokens[i + 1].tokenType == Integer) passingTest = false;
			}
		}

	}

	return passingTest;

}