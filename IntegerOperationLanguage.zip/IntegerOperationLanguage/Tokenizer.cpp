#include "Tokenizer.hpp"

// prototype helper function
Type typeOfCharacter(char character);

Tokenizer::Tokenizer() {
	this->tokenizedList.clear();
}

void Tokenizer::reuse() {
	this->tokenizedList.clear();
}

std::vector<Token> Tokenizer::tokenize(std::string value) {
	// define the states of the algoritim
	int currentIndex = 0;
	std::string currentTokenValue = "";
	Type currentTokenType = blank; // what was previouly being bulit on
	
	// run thorugh the list until the end has been reached
	while (currentIndex < value.size()) {
		// if a - sign has been reached
		if (value.at(currentIndex) == '-') {

			// flush out any currently proccessed integers or refrences beofre appending new opeprations
			if (currentTokenType == Integer || currentTokenType == Reference) {
				tokenizedList.push_back(Token{ currentTokenType, currentTokenValue });
				currentTokenType = blank;
				currentTokenValue = "";
			}

			// if we are currently reading the first index and the string has more than one charater
			if (currentIndex == 0 && value.size() > 1) {
				// if the value next to the first character is an integer
				if (typeOfCharacter(value[currentIndex + 1]) == Integer) {
					// start a new integer
					currentTokenValue += value[currentIndex];
					currentTokenType = Integer;
				}
				else { // if it is not a number
					// push the - symbol as an Operation and reset state
					this->tokenizedList.push_back(Token{ Subtract, "-" });
					currentTokenType = blank;
					currentTokenValue = "";
				}
			}
			else if (currentIndex == value.size() - 1) { // if currently at the last index
				// push the - symbol as an opperator and reset state
				this->tokenizedList.push_back(Token{ Subtract, "-" });
				currentTokenType = blank;
				currentTokenValue = "";
			}
			else { // if it is in the middle somewhere next to two things
				// define some states of the - symbol 
				bool nextIsDigit = (typeOfCharacter(value[currentIndex + 1]) == Integer);
				bool prevIsNumber = (!tokenizedList.empty() &&
					(tokenizedList.back().tokenType == Integer || tokenizedList.back().tokenType == Reference));

				// if it has a number to its left
				if (prevIsNumber) {
					// push it as a subtraction opperater and reset the state
					this->tokenizedList.push_back(Token{ Subtract, "-" });
					currentTokenType = blank;
					currentTokenValue = "";
				}
				else if (nextIsDigit) { // if the next character in the string is a number
					// start a new integer token
					currentTokenValue += value[currentIndex];
					currentTokenType = Integer;
				}
				else { // if neither are true
					// push a minus opperator and reset states;
					this->tokenizedList.push_back(Token{ Subtract, "-" });
					currentTokenType = blank;
					currentTokenValue = "";
				}
			}
		}
		// when a blank space has been reached
		else if (value.at(currentIndex) == ' ') {
			// test if the current token type is not blank
			if (currentTokenType != blank) {
				// if so, see if we were previously reading a reference
				if (currentTokenType == Reference) {
					// if this refernece has the value of our print keyword
					if (currentTokenValue == "PRINT") {
						// convert it to a print statment
						currentTokenType = Print;
					}
				}
				// push the operation to the back of the tokenized list
				this->tokenizedList.push_back(Token{ currentTokenType, currentTokenValue });
			}
			// reset the state to represent the blank we just reached
			currentTokenType = blank;
			currentTokenValue = "";
		} else {
			// test the type of character we are currently reading
			Type currentlyAt = typeOfCharacter(value.at(currentIndex));

			// in the case that you are currently reading a refence or integer
			if (currentTokenType == Reference || currentTokenType == Integer) {
				// if the type matches what we are were reading already
				if ((currentlyAt == Reference && currentTokenType == Reference) || (currentlyAt == Integer && currentTokenType == Integer)) {
					// continue to build upon that integer or refernece
					currentTokenValue += value.at(currentIndex);
				}
				else {
					// since we have reached the end of our type, append the token to our list
					this->tokenizedList.push_back(Token{ currentTokenType, currentTokenValue });
					// redefine states based upon current location
					currentTokenType = currentlyAt;
					currentTokenValue = value.at(currentIndex);

					// imediatly push an operation token if we come accoss one
					if (currentlyAt == Add || currentlyAt == Subtract || currentlyAt == Multiply || currentlyAt == Divide || currentlyAt == Assign) {
						this->tokenizedList.push_back(Token{ currentTokenType, currentTokenValue });
						// reset states after appending the Operation token
						currentTokenValue = "";
						currentTokenType = blank;
					}
				}
			}
			else { // if currently at a blank or an Operation

				// redefine type to match new position
				currentTokenType = currentlyAt;
				currentTokenValue = value.at(currentIndex);

				// imediatly push an operation token
				if (currentlyAt == Add || currentlyAt == Subtract || currentlyAt == Multiply || currentlyAt == Divide || currentlyAt == Assign) {
					this->tokenizedList.push_back(Token{ currentTokenType, currentTokenValue });
					// reset states after appending the Operation token
					currentTokenValue = "";
					currentTokenType = blank;
				}
			}
		}

		// increnment loop counter
		currentIndex++;
	}

	// if a token was in the middle of proccessing at the end of the loop
	if (currentTokenType != blank) {
		// push the final token
		this->tokenizedList.push_back(Token{ currentTokenType, currentTokenValue });
	}

	// return the list
	return tokenizedList;

}

// helper function
Type typeOfCharacter(char character) {
	switch (character) {
	case '*':
		return Multiply;
	case '/':
		return Divide;
	case '-':
		return Subtract;
	case '+':
		return Add;
	case '=':
		return Assign;
	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':
		return Integer;
	default:
		return Reference;
	}
}