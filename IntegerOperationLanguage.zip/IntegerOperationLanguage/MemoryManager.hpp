#ifndef MEMORY_MANAGER_SPECIFICATION_HPP
#define MEMORY_MANAGER_SPECIFICATION_HPP

#include <unordered_map>
#include <string>

class MemoryManager {
	private:
		std::unordered_map<std::string, int> variables;
	public:
		MemoryManager();
		bool isInMemory(std::string name);
		bool addToMemory(std::string name);
		bool addToMemory(std::string name, int value);
		bool editMemory(std::string name, int value);

		int getValue(std::string name);
};

#endif