#ifndef TOKENIZER_SPECIFICATION_HPP
#define TOKENIZER_SPECIFICATION_HPP

#include <string>
#include <vector>

enum Type {
	Multiply,
	Divide,
	Add,
	Subtract,
	Assign,
	Integer,
	Reference,
	Print, 
	blank
};

struct Token{
	Type tokenType;
	std::string value;
};

class Tokenizer {
	private:
		std::vector<Token> tokenizedList;
	public:
		Tokenizer();
		std::vector<Token> tokenize(std::string value);
		void reuse();
};

#endif