#ifndef PARSER_SPECIFICATION_HPP
#define PARSER_SPECIFICATION_HPP

#include "Tokenizer.hpp"

class Parser {
	private:
		std::vector<Token> tokens;
	public:
		Parser();
		void giveTokens(std::vector<Token> tokens);
		bool verify();
		void reuse();
};

#endif